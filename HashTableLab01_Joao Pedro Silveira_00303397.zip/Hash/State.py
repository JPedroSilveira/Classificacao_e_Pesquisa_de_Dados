import enum


class HashState(enum.Enum):
    empty = -1  # Significa que o local esta vazio
